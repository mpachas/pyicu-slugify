from .slugify import pyicu_slugify

__version__ = "0.1.0"
__all__ = ["pyicu_slugify"]